export default function returnFalse() {
    return false;
}
